import { Abortable, AsyncTask, IAsyncTaskFactory } from '@lirx/async-task';
import { noop } from '@lirx/utils';
import { IAsyncTaskIterator } from '../../async-task-iterator.type';
import { IAsyncTaskIteratorResult } from '../../traits/next/async-task-iterator.next.function-definition';

export function createAsyncTaskIteratorFromFactory<GValue>(
  factory: IAsyncTaskFactory<IAsyncTaskIteratorResult<GValue>>,
): IAsyncTaskIterator<GValue> {
  const queue: AsyncTask<any> = AsyncTask.void(Abortable.never);

  const next = (
    abortable: Abortable,
  ): AsyncTask<IAsyncTaskIteratorResult<GValue>> => {
    return AsyncTask.switchAbortable(queue, abortable)
      .errored(noop)
      .successful(factory);
  };

  return {
    next,
  };
}

