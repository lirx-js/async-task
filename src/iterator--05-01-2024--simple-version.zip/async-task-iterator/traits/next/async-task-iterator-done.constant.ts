// export const AsyncTaskIteratorDone = Symbol();
// export type IAsyncTaskIteratorDone = typeof AsyncTaskIteratorDone;

export const AsyncTaskIteratorDone: IteratorReturnResult<void> = Object.freeze({
  done: true,
  value: void 0,
});
