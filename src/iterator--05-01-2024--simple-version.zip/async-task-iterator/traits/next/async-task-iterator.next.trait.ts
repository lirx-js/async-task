import { IAsyncTaskIteratorNextFunction } from './async-task-iterator.next.function-definition';

export interface IAsyncTaskIteratorNextTrait<GValue> {
  readonly next: IAsyncTaskIteratorNextFunction<GValue>;
}
