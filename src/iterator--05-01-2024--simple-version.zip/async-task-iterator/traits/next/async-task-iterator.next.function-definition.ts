import { Abortable, AsyncTask } from '@lirx/async-task';

export type IAsyncTaskIteratorResult<GValue> = IteratorResult<GValue, void>;

export interface IAsyncTaskIteratorNextFunction<GValue> {
  (
    abortable: Abortable,
  ): AsyncTask<IAsyncTaskIteratorResult<GValue>>;
}

