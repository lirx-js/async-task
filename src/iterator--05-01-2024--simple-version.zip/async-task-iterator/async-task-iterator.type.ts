import { IAsyncTaskIteratorNextTrait } from './traits/next/async-task-iterator.next.trait';

export interface IAsyncTaskIterator<GValue> extends //
  IAsyncTaskIteratorNextTrait<GValue>
//
{

}
