import { IAsyncTaskConstraint } from '../async-task/types/async-task-constraint.type';
import { Abortable } from '../abortable/abortable.class';
import { AsyncTask } from '../async-task/async-task.class';

export interface IAsyncTaskIteratorNextFunction<GValue extends IAsyncTaskConstraint<GValue>, GReturn, GNext> {
  (
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>>;

  (
    value: GNext,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>>;
}

export interface IAsyncTaskIteratorReturnFunction<GValue extends IAsyncTaskConstraint<GValue>, GReturn, GNext> {
  (
    value: GReturn,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>>;
}

export interface IAsyncTaskIteratorThrowFunction<GValue extends IAsyncTaskConstraint<GValue>, GReturn, GNext> {
  (
    error: any,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>>;
}

export interface IAsyncTaskIterator<GValue extends IAsyncTaskConstraint<GValue>, GReturn, GNext> {
  readonly next: IAsyncTaskIteratorNextFunction<GValue, GReturn, GNext>;
  readonly return: IAsyncTaskIteratorReturnFunction<GValue, GReturn, GNext>;
  readonly throw: IAsyncTaskIteratorThrowFunction<GValue, GReturn, GNext>;
}

// export interface IAsyncTaskIterator<GValue extends IAsyncTaskConstraint<GValue>, GReturn, GNext> {
//   next(
//     abortable: Abortable,
//   ): AsyncTask<IteratorResult<GValue, GReturn>>;
//
//   next(
//     value: GNext,
//     abortable: Abortable,
//   ): AsyncTask<IteratorResult<GValue, GReturn>>;
//
//   return(
//     value: GReturn,
//     abortable: Abortable,
//   ): AsyncTask<IteratorResult<GValue, GReturn>>;
//
//   throw(
//     error: any,
//     abortable: Abortable,
//   ): AsyncTask<IteratorResult<GValue, GReturn>>;
// }

