import { IAsyncTaskIterator } from './async-task-iterator.type';
import { IAsyncTaskConstraint } from '../async-task/types/async-task-constraint.type';
import { AsyncTask } from '../async-task/async-task.class';
import { Abortable } from '../abortable/abortable.class';
import { IAsyncTaskFactory } from '../async-task/types/factory/async-task-factory.type';
import { IUnsubscribe } from '@lirx/unsubscribe';
import { IAsyncTaskInput } from '../async-task/types/async-task-input.type';

/*---------*/

// export interface IPromiseWithResolversReturn<GValue> {
//   readonly promise: Promise<GValue>;
//   readonly resolve: (value: GValue | PromiseLike<GValue>) => void,
//   readonly reject: (reason?: any) => void,
// }
//
// export function promiseWithResolvers<GValue>(): IPromiseWithResolversReturn<GValue> {
//   // Promise.withResolvers();
//
//   let resolve!: (value: GValue | PromiseLike<GValue>) => void;
//   let reject!: (reason?: any) => void;
//
//   const promise = new Promise<GValue>((
//     _resolve: (value: GValue | PromiseLike<GValue>) => void,
//     _reject: (reason?: any) => void,
//   ): void => {
//     resolve = _resolve;
//     reject = _reject;
//   });
//
//   return {
//     promise,
//     resolve,
//     reject,
//   };
// }

/*---------*/

export interface IAsyncTaskIteratorAwaitFunction {
  <GValue extends IAsyncTaskConstraint<GValue>>(
    factory: IAsyncTaskFactory<GValue>,
  ): Promise<GValue>;
}

export interface IAsyncTaskIteratorInput<GValue, GReturn, GNext, GArguments extends readonly any[]> {
  (
    __await__: IAsyncTaskIteratorAwaitFunction,
    ...args: GArguments
  ): AsyncGenerator<GValue, GReturn, GNext>;
}

export function createAsyncTaskIterator<GValue extends IAsyncTaskConstraint<GValue>, GReturn, GNext, GArguments extends readonly any[]>(
  generator: IAsyncTaskIteratorInput<GValue, GReturn, GNext, GArguments>,
  ...args: GArguments
): IAsyncTaskIterator<GValue, GReturn, GNext> {
  let queue: AsyncTask<IteratorResult<GValue, GReturn>> | undefined;

  type IAbortableListener = (abortable: Abortable) => void;

  const listeners: IAbortableListener[] = [];
  let _abortable: Abortable;
  let updating: boolean = false;

  const listenToAbortable = (
    emit: IAbortableListener,
  ): IUnsubscribe => {
    listeners.push(emit);
    emit(_abortable);
    return (): void => {
      if (updating) {
        throw new Error(`Cannot unsubscribe while updating`);
      } else {
        listeners.splice(listeners.indexOf(emit), 1);
      }
    };
  };

  const updateAbortable = (
    abortable: Abortable,
  ): void => {
    updating = true;
    _abortable = abortable;
    for (let i = 0, l = listeners.length; i < l; i++) {
      listeners[i](abortable);
    }
    updating = false;
  };

  const __await__: IAsyncTaskIteratorAwaitFunction = <GValue extends IAsyncTaskConstraint<GValue>>(
    factory: IAsyncTaskFactory<GValue>,
  ): Promise<GValue> => {
    return new Promise<GValue>((
      resolve: (value: GValue) => void,
      reject: (reason: any) => void,
    ): void => {
      const unsubscribe = listenToAbortable((abortable: Abortable): void => {
        AsyncTask.fromFactory(factory, abortable)
          .then(
            (value: GValue): void => {
              unsubscribe();
              resolve(value);
            },
            (error: any): void => {
              unsubscribe();
              reject(error);
            },
          );
      });
    });
  };

  const _iterate = (
    iterate: () => Promise<IteratorResult<GValue, GReturn>>,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>> => {
    updateAbortable(abortable);
    return AsyncTask.fromFactory(iterate, abortable);
  };

  const _iterateWithQueue = (
    iterate: () => Promise<IteratorResult<GValue, GReturn>>,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>> => {
    return queue = (
      (queue === void 0)
        ? _iterate(iterate, abortable)
        : AsyncTask.switchAbortable(queue, abortable)
          .settled((_, abortable: Abortable): IAsyncTaskInput<IteratorResult<GValue, GReturn>> => {
            return _iterate(iterate, abortable);
          })
    );
  };

  const iterator: AsyncGenerator<GValue, GReturn, GNext> = generator(__await__, ...args);

  return {
    next: (
      ...args: any[]
    ): AsyncTask<IteratorResult<GValue, GReturn>> => {
      if (args.length === 1) {
        return _iterateWithQueue(() => iterator.next(), args[0]);
      } else {
        return _iterateWithQueue(() => iterator.next(args[0]), args[1]);
      }
    },
    return: (
      value: GReturn,
      abortable: Abortable,
    ): AsyncTask<IteratorResult<GValue, GReturn>> => {
      return _iterateWithQueue(() => iterator.return(value), abortable);
    },
    throw: (
      error: any,
      abortable: Abortable,
    ): AsyncTask<IteratorResult<GValue, GReturn>> => {
      return _iterateWithQueue(() => iterator.throw(error), abortable);
    },
  };
}

// export function createAsyncTaskIterator<GValue extends IAsyncTaskConstraint<GValue>, GReturn, GNext>(
//   iterator: IAsyncTaskGenerator<GValue, GReturn, GNext>,
// ): IAsyncTaskIterator<GValue, GReturn, GNext> {
//   let queue: AsyncTask<IteratorResult<GValue, GReturn>> | undefined;
//
//   const _iterate = (
//     iterate: (abortable: Abortable) => IteratorResult<IAsyncTaskGeneratorValue<GValue>, GReturn>,
//     abortable: Abortable,
//   ): AsyncTask<IteratorResult<GValue, GReturn>> => {
//     return AsyncTask.fromFactory<IteratorResult<IAsyncTaskGeneratorValue<GValue>, GReturn>>(iterate, abortable)
//       .successful((
//         result: IteratorResult<IAsyncTaskGeneratorValue<GValue>, GReturn>,
//         abortable: Abortable,
//       ): IAsyncTaskInput<IteratorResult<GValue, GReturn>> => {
//         if (result.done) {
//           return result;
//         } else {
//           const token: IAsyncTaskGeneratorValue<GValue> = result.value;
//
//           if (isAsyncTaskGeneratorYieldToken(token)) {
//             return {
//               done: false,
//               value: token.value,
//             };
//           } else if (isAsyncTaskGeneratorAwaitToken(token)) {
//             return AsyncTask.fromFactory(token.factory, abortable)
//               .then(
//                 (
//                   value: GValue,
//                   abortable: Abortable,
//                 ): AsyncTask<IteratorResult<GValue, GReturn>> => {
//                   return _iterate(
//                     () => iterator.next(value),
//                     abortable,
//                   );
//                 },
//                 (
//                   error: unknown,
//                   abortable: Abortable,
//                 ): AsyncTask<IteratorResult<GValue, GReturn>> => {
//                   return _iterate(
//                     () => iterator.throw(error),
//                     abortable,
//                   );
//                 },
//               );
//           } else {
//             return AsyncTask.error(
//               new Error(`Unknown type: ${token.type}`),
//               abortable,
//             );
//           }
//         }
//       });
//   };
//
//   const _iterateWithQueue = (
//     iterate: (abortable: Abortable) => IteratorResult<IAsyncTaskGeneratorValue<GValue>, GReturn>,
//     abortable: Abortable,
//   ): AsyncTask<IteratorResult<GValue, GReturn>> => {
//     return queue = (
//       (queue === void 0)
//         ? _iterate(iterate, abortable)
//         : AsyncTask.switchAbortable(queue, abortable)
//           .settled((_, abortable: Abortable): AsyncTask<IteratorResult<GValue, GReturn>> => {
//             return _iterate(iterate, abortable);
//           })
//     );
//   };
//
//   return {
//     next: (
//       ...args: any[]
//     ): AsyncTask<IteratorResult<GValue, GReturn>> => {
//       if (args.length === 1) {
//         return _iterateWithQueue(() => iterator.next(), args[0]);
//       } else {
//         return _iterateWithQueue(() => iterator.next(args[0]), args[1]);
//       }
//     },
//     return: (
//       value: GReturn,
//       abortable: Abortable,
//     ): AsyncTask<IteratorResult<GValue, GReturn>> => {
//       return _iterateWithQueue(() => iterator.return(value), abortable);
//     },
//     throw: (
//       error: any,
//       abortable: Abortable,
//     ): AsyncTask<IteratorResult<GValue, GReturn>> => {
//       return _iterateWithQueue(() => iterator.throw(error), abortable);
//     },
//   };
// }


