import { IAsyncTaskConstraint } from '../async-task/types/async-task-constraint.type';
import { IAsyncTaskFactory } from '../async-task/types/factory/async-task-factory.type';

export interface IAsyncTaskIteratorAwaitFunction {
  <GValue extends IAsyncTaskConstraint<GValue>>(
    factory: IAsyncTaskFactory<GValue>,
  ): Promise<GValue>;
}
