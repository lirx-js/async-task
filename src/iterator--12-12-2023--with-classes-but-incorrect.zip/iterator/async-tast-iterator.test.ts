import { asyncTimeout } from '../async-task/built-in/async-timeout';
import {  AsyncTaskIteratorContext, AsyncTaskIterable } from './create-async-task-iterator';
import { Abortable } from '../abortable/abortable.class';
import { AsyncTask } from '../async-task/async-task.class';

describe('IAsyncTaskIterator', () => {

  it('should work', async () => {
    const data = new AsyncTaskIterable<number>(
      async function* (
        ctx: AsyncTaskIteratorContext<number>,
      ): AsyncGenerator<number> {
        for (let i = 0; i < 2; i++) {
          yield ctx.task((abortable: Abortable) => asyncTimeout(100, abortable).successful(() => i));
        }
      },
    );

    const data2 = new AsyncTaskIterable<number>(
      async function*(
        ctx: AsyncTaskIteratorContext<number>,
      ): AsyncGenerator<number> {
        yield* ctx.delegateTo(data);
        yield 10;
      },
    );

    const abortable = Abortable.never;

    const it = data2.iterator();
    it.next(Abortable.timeout(50));
    console.log(await it.next(abortable).toPromise());
    // it.next(Abortable.timeout(50));
    console.log(await it.next(abortable).toPromise());
    console.log(await it.next(abortable).toPromise());
    console.log(await it.next(abortable).toPromise());
  });
});

