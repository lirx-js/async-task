import { IUnsubscribe } from '@lirx/unsubscribe';
import { Abortable } from '../abortable/abortable.class';
import { AsyncTask } from '../async-task/async-task.class';
import { IAsyncTaskConstraint } from '../async-task/types/async-task-constraint.type';
import { IAsyncTaskInput } from '../async-task/types/async-task-input.type';
import { IAsyncTaskFactory } from '../async-task/types/factory/async-task-factory.type';
import { IAsyncIterable } from './types/async-iterable.type';
import { IAsyncTaskIterable, IAsyncTaskIterator } from './async-task-iterator.type';

/*---------*/

// export interface IPromiseWithResolversReturn<GValue> {
//   readonly promise: Promise<GValue>;
//   readonly resolve: (value: GValue | PromiseLike<GValue>) => void,
//   readonly reject: (reason?: any) => void,
// }
//
// export function promiseWithResolvers<GValue>(): IPromiseWithResolversReturn<GValue> {
//   // Promise.withResolvers();
//
//   let resolve!: (value: GValue | PromiseLike<GValue>) => void;
//   let reject!: (reason?: any) => void;
//
//   const promise = new Promise<GValue>((
//     _resolve: (value: GValue | PromiseLike<GValue>) => void,
//     _reject: (reason?: any) => void,
//   ): void => {
//     resolve = _resolve;
//     reject = _reject;
//   });
//
//   return {
//     promise,
//     resolve,
//     reject,
//   };
// }

/*---------*/

/*---------*/

export class AsyncTaskIterable<GValue = unknown, GReturn = any, GNext = unknown> implements IAsyncTaskIterable<GValue, GReturn, GNext> {
  readonly #factory: IAsyncTaskIteratorFactory<GValue, GReturn, GNext>;

  constructor(
    factory: IAsyncTaskIteratorFactory<GValue, GReturn, GNext>,
  ) {
    this.#factory = factory;
  }

  get factory(): IAsyncTaskIteratorFactory<GValue, GReturn, GNext> {
    return this.#factory;
  }

  iterator(): AsyncTaskIterator<GValue, GReturn, GNext> {
    return new AsyncTaskIterator<GValue, GReturn, GNext>(
      this.#factory,
    );
  }
}

/*---------*/

export interface IAsyncTaskIteratorContextTaskFunction {
  <GValue extends IAsyncTaskConstraint<GValue>>(
    factory: IAsyncTaskFactory<GValue>,
  ): Promise<GValue>;
}

export interface IAsyncTaskIteratorContextDelegateToFunction<GValue, GReturn, GNext> {
  (
    iterable: IAsyncTaskIterable<GValue, GReturn, GNext>,
  ): IAsyncIterable<GValue, GReturn, GNext>;
}

export interface IAsyncTaskIteratorContextTaskOptions<GValue, GReturn, GNext> {
  readonly task: IAsyncTaskIteratorContextTaskFunction;
  readonly delegateTo: IAsyncTaskIteratorContextDelegateToFunction<GValue, GReturn, GNext>;
}

export class AsyncTaskIteratorContext<GValue = unknown, GReturn = any, GNext = unknown> {
  readonly #task: IAsyncTaskIteratorContextTaskFunction;
  readonly #delegateTo: IAsyncTaskIteratorContextDelegateToFunction<GValue, GReturn, GNext>;

  constructor(
    {
      task,
      delegateTo,
    }: IAsyncTaskIteratorContextTaskOptions<GValue, GReturn, GNext>,
  ) {
    this.#task = task;
    this.#delegateTo = delegateTo;
  }

  task<GValue extends IAsyncTaskConstraint<GValue>>(
    factory: IAsyncTaskFactory<GValue>,
  ): Promise<GValue> {
    return this.#task(factory);
  }

  delegateTo(
    iterable: IAsyncTaskIterable<GValue, GReturn, GNext>,
  ): IAsyncIterable<GValue, GReturn, GNext> {
    return this.#delegateTo(iterable);
  }
}

/*---------*/

export interface IAsyncTaskIteratorFactory<GValue, GReturn, GNext> {
  (
    context: AsyncTaskIteratorContext<GValue, GReturn, GNext>,
  ): AsyncGenerator<GValue, GReturn, GNext>;
}

type IAbortableListener = (abortable: Abortable) => void;

export class AsyncTaskIterator<GValue = unknown, GReturn = any, GNext = unknown> implements IAsyncTaskIterator<GValue, GReturn, GNext> {
  #queue: AsyncTask<IteratorResult<GValue, GReturn>> | undefined;
  readonly #listeners: IAbortableListener[];
  #abortable!: Abortable;
  #updating: boolean;
  readonly #iterator: AsyncGenerator<GValue, GReturn, GNext>;

  constructor(
    factory: IAsyncTaskIteratorFactory<GValue, GReturn, GNext>,
  ) {
    this.#listeners = [];
    this.#updating = false;

    const context = new AsyncTaskIteratorContext<GValue, GReturn, GNext>({
      task: <GValue extends IAsyncTaskConstraint<GValue>>(
        factory: IAsyncTaskFactory<GValue>,
      ): Promise<GValue> => {
        return new Promise<GValue>((
          resolve: (value: GValue) => void,
          reject: (reason: any) => void,
        ): void => {
          const unsubscribe: IUnsubscribe = this.#listenToAbortable((abortable: Abortable): void => {
            AsyncTask.fromFactory(factory, abortable)
              .then(
                (value: GValue): void => {
                  unsubscribe();
                  resolve(value);
                },
                (error: any): void => {
                  unsubscribe();
                  reject(error);
                },
              );
          });
        });
      },
      delegateTo: (
        iterable: IAsyncTaskIterable<GValue, GReturn, GNext>,
      ): IAsyncIterable<GValue, GReturn, GNext> => {
        return iterable.factory(context);
      },
    });

    this.#iterator = factory(context);
  }

  next(
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>>;
  next(
    value: GNext,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>>;
  next(
    ...args: any[]
  ): AsyncTask<IteratorResult<GValue, GReturn>> {
    if (args.length === 1) {
      return this.#iterateWithQueue(() => this.#iterator.next(), args[0]);
    } else {
      return this.#iterateWithQueue(() => this.#iterator.next(args[0]), args[1]);
    }
  }

  return(
    value: GReturn,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>> {
    return this.#iterateWithQueue(() => this.#iterator.return(value), abortable);
  }

  throw(
    error: any,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>> {
    return this.#iterateWithQueue(() => this.#iterator.throw(error), abortable);
  }

  /* PRIVATE */

  #listenToAbortable(
    emit: IAbortableListener,
  ): IUnsubscribe {
    this.#listeners.push(emit);
    emit(this.#abortable);
    return (): void => {
      if (this.#updating) {
        throw new Error(`Cannot unsubscribe while updating`);
      } else {
        this.#listeners.splice(this.#listeners.indexOf(emit), 1);
      }
    };
  }

  #updateAbortable(
    abortable: Abortable,
  ): void {
    this.#updating = true;
    this.#abortable = abortable;
    for (let i = 0, l = this.#listeners.length; i < l; i++) {
      this.#listeners[i](abortable);
    }
    this.#updating = false;
  }

  #iterate(
    iterate: () => Promise<IteratorResult<GValue, GReturn>>,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>> {
    this.#updateAbortable(abortable);
    return AsyncTask.fromFactory(iterate, abortable);
  }

  #iterateWithQueue(
    iterate: () => Promise<IteratorResult<GValue, GReturn>>,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>> {
    return this.#queue = (
      (this.#queue === void 0)
        ? this.#iterate(iterate, abortable)
        : AsyncTask.switchAbortable(this.#queue, abortable)
          .settled((_, abortable: Abortable): IAsyncTaskInput<IteratorResult<GValue, GReturn>> => {
            return this.#iterate(iterate, abortable);
          })
    );
  };
}





