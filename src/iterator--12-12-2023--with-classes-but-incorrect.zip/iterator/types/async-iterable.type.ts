export interface IAsyncIterable<GValue = unknown, GReturn = any, GNext = unknown> {
  [Symbol.asyncIterator](): AsyncGenerator<GValue, GReturn, GNext>;
}
