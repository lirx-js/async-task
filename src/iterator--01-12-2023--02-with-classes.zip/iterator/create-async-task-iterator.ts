import { IAsyncTaskIterator, IAsyncTaskIterable } from './async-task-iterator.type';
import { IAsyncTaskConstraint } from '../async-task/types/async-task-constraint.type';
import { AsyncTask } from '../async-task/async-task.class';
import { Abortable } from '../abortable/abortable.class';
import { IAsyncTaskFactory } from '../async-task/types/factory/async-task-factory.type';
import { IUnsubscribe } from '@lirx/unsubscribe';
import { IAsyncTaskInput } from '../async-task/types/async-task-input.type';
import { IAsyncTaskIteratorAwaitFunction } from './async-task-iterator-await-function.type';

/*---------*/

// export interface IPromiseWithResolversReturn<GValue> {
//   readonly promise: Promise<GValue>;
//   readonly resolve: (value: GValue | PromiseLike<GValue>) => void,
//   readonly reject: (reason?: any) => void,
// }
//
// export function promiseWithResolvers<GValue>(): IPromiseWithResolversReturn<GValue> {
//   // Promise.withResolvers();
//
//   let resolve!: (value: GValue | PromiseLike<GValue>) => void;
//   let reject!: (reason?: any) => void;
//
//   const promise = new Promise<GValue>((
//     _resolve: (value: GValue | PromiseLike<GValue>) => void,
//     _reject: (reason?: any) => void,
//   ): void => {
//     resolve = _resolve;
//     reject = _reject;
//   });
//
//   return {
//     promise,
//     resolve,
//     reject,
//   };
// }

/*---------*/

export interface IAsyncTaskIteratorFactory<GValue, GReturn, GNext> {
  (
    __await__: IAsyncTaskIteratorAwaitFunction,
  ): AsyncGenerator<GValue, GReturn, GNext>;
}

type IAbortableListener = (abortable: Abortable) => void;

export class AsyncTaskIterable<GValue = unknown, GReturn = any, GNext = unknown> implements IAsyncTaskIterable<GValue, GReturn, GNext> {
  readonly #factory: IAsyncTaskIteratorFactory<GValue, GReturn, GNext>;

  constructor(
    factory: IAsyncTaskIteratorFactory<GValue, GReturn, GNext>,
  ) {
    this.#factory = factory;
  }

  iterator(): AsyncTaskIterator<GValue, GReturn, GNext> {
    return new AsyncTaskIterator<GValue, GReturn, GNext>(
      this.#factory,
    );
  }

  delegate(
    __await__: IAsyncTaskIteratorAwaitFunction,
  ): AsyncGenerator<GValue, GReturn, GNext> {
    return this.#factory(__await__);
  }
}

export class AsyncTaskIterator<GValue = unknown, GReturn = any, GNext = unknown> implements IAsyncTaskIterator<GValue, GReturn, GNext> {
  #queue: AsyncTask<IteratorResult<GValue, GReturn>> | undefined;
  readonly #listeners: IAbortableListener[];
  #abortable!: Abortable;
  #updating: boolean;
  readonly #iterator: AsyncGenerator<GValue, GReturn, GNext>;

  constructor(
    factory: IAsyncTaskIteratorFactory<GValue, GReturn, GNext>,
  ) {
    this.#listeners = [];
    this.#updating = false;

    this.#iterator = factory(
      <GValue extends IAsyncTaskConstraint<GValue>>(
        factory: IAsyncTaskFactory<GValue>,
      ): Promise<GValue> => {
        return new Promise<GValue>((
          resolve: (value: GValue) => void,
          reject: (reason: any) => void,
        ): void => {
          const unsubscribe = this.#listenToAbortable((abortable: Abortable): void => {
            AsyncTask.fromFactory(factory, abortable)
              .then(
                (value: GValue): void => {
                  unsubscribe();
                  resolve(value);
                },
                (error: any): void => {
                  unsubscribe();
                  reject(error);
                },
              );
          });
        });
      },
    );
  }

  next(
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>>;
  next(
    value: GNext,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>>;
  next(
    ...args: any[]
  ): AsyncTask<IteratorResult<GValue, GReturn>> {
    if (args.length === 1) {
      return this.#iterateWithQueue(() => this.#iterator.next(), args[0]);
    } else {
      return this.#iterateWithQueue(() => this.#iterator.next(args[0]), args[1]);
    }
  }

  return(
    value: GReturn,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>> {
    return this.#iterateWithQueue(() => this.#iterator.return(value), abortable);
  }

  throw(
    error: any,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>> {
    return this.#iterateWithQueue(() => this.#iterator.throw(error), abortable);
  }

  /* PRIVATE */

  #listenToAbortable(
    emit: IAbortableListener,
  ): IUnsubscribe {
    this.#listeners.push(emit);
    emit(this.#abortable);
    return (): void => {
      if (this.#updating) {
        throw new Error(`Cannot unsubscribe while updating`);
      } else {
        this.#listeners.splice(this.#listeners.indexOf(emit), 1);
      }
    };
  }

  #updateAbortable(
    abortable: Abortable,
  ): void {
    this.#updating = true;
    this.#abortable = abortable;
    for (let i = 0, l = this.#listeners.length; i < l; i++) {
      this.#listeners[i](abortable);
    }
    this.#updating = false;
  }

  #iterate(
    iterate: () => Promise<IteratorResult<GValue, GReturn>>,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>> {
    this.#updateAbortable(abortable);
    return AsyncTask.fromFactory(iterate, abortable);
  }

  #iterateWithQueue(
    iterate: () => Promise<IteratorResult<GValue, GReturn>>,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>> {
    return this.#queue = (
      (this.#queue === void 0)
        ? this.#iterate(iterate, abortable)
        : AsyncTask.switchAbortable(this.#queue, abortable)
          .settled((_, abortable: Abortable): IAsyncTaskInput<IteratorResult<GValue, GReturn>> => {
            return this.#iterate(iterate, abortable);
          })
    );
  };
}
