import { Abortable } from '../abortable/abortable.class';
import { AsyncTask } from '../async-task/async-task.class';
import { IAsyncTaskIteratorAwaitFunction } from './async-task-iterator-await-function.type';

// TODO traits

export interface IAsyncTaskIteratorNextFunction<GValue, GReturn, GNext> {
  (
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>>;

  (
    value: GNext,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>>;
}

export interface IAsyncTaskIteratorReturnFunction<GValue, GReturn, GNext> {
  (
    value: GReturn,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>>;
}

export interface IAsyncTaskIteratorThrowFunction<GValue, GReturn, GNext> {
  (
    error: any,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>>;
}

export interface IAsyncTaskIterator<GValue = unknown, GReturn = any, GNext = unknown> {
  readonly next: IAsyncTaskIteratorNextFunction<GValue, GReturn, GNext>;
  readonly return: IAsyncTaskIteratorReturnFunction<GValue, GReturn, GNext>;
  readonly throw: IAsyncTaskIteratorThrowFunction<GValue, GReturn, GNext>;
}

// Iterable


export interface IAsyncTaskIterableIteratorFunction<GValue, GReturn, GNext> {
  (): IAsyncTaskIterator<GValue, GReturn, GNext>;
}

export interface IAsyncTaskIterableDelegateFunction<GValue, GReturn, GNext> {
  (
    __await__: IAsyncTaskIteratorAwaitFunction,
  ): AsyncGenerator<GValue, GReturn, GNext>;
}

export interface IAsyncTaskIterable<GValue = unknown, GReturn = any, GNext = unknown> {
  readonly iterator: IAsyncTaskIterableIteratorFunction<GValue, GReturn, GNext>;
  readonly delegate: IAsyncTaskIterableDelegateFunction<GValue, GReturn, GNext>;
}

