import { createAsyncTaskIterator, AsyncTaskIterator } from './create-async-task-iterator';
import { Abortable } from '../abortable/abortable.class';
import { AsyncTask } from '../async-task/async-task.class';
import { IAsyncTaskIteratorAwaitFunction } from './async-task-iterator-await-function.type';

describe('IAsyncTaskIterator', () => {
  // it('should work', async () => {
  //   async function* gen(
  //     __await__: IAsyncTaskIteratorAwaitFunction,
  //   ): AsyncGenerator<number, string, boolean> {
  //     if (await __await__((abortable: Abortable) => AsyncTask.success(false, abortable))) {
  //       yield 8;
  //     } else {
  //       for (let i = 0; i < 2; i++) {
  //         try {
  //           const value: number = await __await__((abortable: Abortable) => AsyncTask.success(i, abortable));
  //           const next: boolean = yield value;
  //           console.log('next', next);
  //         } catch (error: unknown) {
  //           console.log('error', error);
  //         } finally {
  //           console.log('finally');
  //         }
  //       }
  //     }
  //
  //     return '123';
  //   }
  //
  //   const abortable = Abortable.never;
  //
  //   const it = createAsyncTaskIterator(gen);
  //   it.next(Abortable.abort('abc'));
  //   console.log(await it.next(abortable).toPromise());
  //   console.log(await it.throw(123, abortable).toPromise());
  //   console.log(await it.next(true, abortable).toPromise());
  //   console.log(await it.next(false, abortable).toPromise());
  // });

  it('should work2', async () => {
    const data = new AsyncTaskIterator(
      async function* (
        __await__: IAsyncTaskIteratorAwaitFunction,
      ): AsyncGenerator<number> {
        for (let i = 0; i < 2; i++) {
          yield __await__((abortable: Abortable) => AsyncTask.success(i, abortable));
        }
      },
    );

    const data2 = new AsyncTaskIterator(
      async function*(
        __await__: IAsyncTaskIteratorAwaitFunction,
      ): AsyncGenerator<number> {
        // yield* data(__await__);
        yield* { next: () => null as any};
        yield 10;
      },
    );

    const abortable = Abortable.never;

    const it = createAsyncTaskIterator(data2);
    it.next(Abortable.abort('abc'));
    console.log(await it.next(abortable).toPromise());
    console.log(await it.next(abortable).toPromise());
    console.log(await it.next(abortable).toPromise());
    console.log(await it.next(abortable).toPromise());
  });
});

