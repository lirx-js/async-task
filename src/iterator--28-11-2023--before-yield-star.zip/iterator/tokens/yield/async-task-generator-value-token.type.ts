import { IAsyncTaskGeneratorSharedToken, IGenericAsyncTaskGeneratorSharedToken } from '../sharred/async-task-generator-shared-token.type';
import { IAsyncTaskConstraint } from '../../../async-task/types/async-task-constraint.type';

export interface IAsyncTaskGeneratorYieldToken<GValue> extends IAsyncTaskGeneratorSharedToken<'yield'> {
  readonly value: GValue;
}

export function YIELD<GValue>(
  value: GValue,
): IAsyncTaskGeneratorYieldToken<GValue> {
  return {
    type: 'yield',
    value,
  };
}

export function isAsyncTaskGeneratorYieldToken<GValue extends IAsyncTaskConstraint<GValue>>(
  input: IGenericAsyncTaskGeneratorSharedToken,
): input is IAsyncTaskGeneratorYieldToken<GValue> {
  return input.type === 'yield';
}
