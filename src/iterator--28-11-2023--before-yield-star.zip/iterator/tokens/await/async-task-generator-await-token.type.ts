import { IAsyncTaskGeneratorSharedToken, IGenericAsyncTaskGeneratorSharedToken } from '../sharred/async-task-generator-shared-token.type';
import { IAsyncTaskFactory } from '../../../async-task/types/factory/async-task-factory.type';
import { IAsyncTaskConstraint } from '../../../async-task/types/async-task-constraint.type';

export interface IAsyncTaskGeneratorAwaitToken<GValue extends IAsyncTaskConstraint<GValue>> extends IAsyncTaskGeneratorSharedToken<'await'> {
  readonly factory: IAsyncTaskFactory<GValue>;
}

export function AWAIT<GValue extends IAsyncTaskConstraint<GValue>>(
  factory: IAsyncTaskFactory<GValue>,
): IAsyncTaskGeneratorAwaitToken<GValue> {
  return {
    type: 'await',
    factory,
  };
}

export function isAsyncTaskGeneratorAwaitToken<GValue extends IAsyncTaskConstraint<GValue>>(
  input: IGenericAsyncTaskGeneratorSharedToken,
): input is IAsyncTaskGeneratorAwaitToken<GValue> {
  return input.type === 'await';
}
