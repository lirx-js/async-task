export interface IAsyncTaskGeneratorSharedToken<GType extends string> {
  readonly type: GType;
}

export type IGenericAsyncTaskGeneratorSharedToken = IAsyncTaskGeneratorSharedToken<any>;
