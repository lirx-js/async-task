import { IAsyncTaskConstraint } from '../../async-task/types/async-task-constraint.type';
import { IAsyncTaskIterator } from '../async-task-iterator.type';
import { IAsyncTaskGenerator } from '../async-task-generator.type';
import { AWAIT } from './await/async-task-generator-await-token.type';
import { Abortable } from '../../abortable/abortable.class';
import { AsyncTask } from '../../async-task/async-task.class';
import { YIELD } from './yield/async-task-generator-value-token.type';

export function* YIELD_STAR<GValue extends IAsyncTaskConstraint<GValue>, GReturn, GNext>(
  iterator: IAsyncTaskIterator<GValue, GReturn, GNext>,
): IAsyncTaskGenerator<GValue, GReturn, GNext> {
  try {
    let result: IteratorResult<GValue, GReturn> = yield AWAIT((abortable: Abortable): AsyncTask<IteratorResult<GValue, GReturn>> => iterator.next(abortable));

    while (true) {
      if (result.done) {
        return result.value;
      } else {
        try {
          const next: GNext = yield YIELD(result.value);
          result = yield AWAIT((abortable: Abortable): AsyncTask<IteratorResult<GValue, GReturn>> => iterator.next(next, abortable));
        } catch (error: unknown) {
          result = yield AWAIT((abortable: Abortable): AsyncTask<IteratorResult<GValue, GReturn>> => iterator.throw(error, abortable));
        }
      }
    }
  } finally {
    // INFO: not sure about this portion
    iterator.return(void 0 as any, Abortable.never);
  }
}
