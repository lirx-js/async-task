import { IAsyncTaskGeneratorAwaitToken } from './tokens/await/async-task-generator-await-token.type';
import { IAsyncTaskConstraint } from '../async-task/types/async-task-constraint.type';
import { IAsyncTaskGeneratorYieldToken } from './tokens/yield/async-task-generator-value-token.type';

export type IAsyncTaskGeneratorValue<GValue extends IAsyncTaskConstraint<GValue>> =
  | IAsyncTaskGeneratorYieldToken<GValue>
  | IAsyncTaskGeneratorAwaitToken<any>
  ;

export type IAsyncTaskGenerator<GValue extends IAsyncTaskConstraint<GValue>, GReturn, GNext> =
  Generator<IAsyncTaskGeneratorValue<GValue>, GReturn, GNext | any>;
