## createAsyncTaskIterator

```ts

function* gen(): IAsyncTaskGenerator<number, string, any> {
  if (yield AWAIT((abortable: Abortable) => AsyncTask.success(true, abortable))) {
    yield YIELD((abortable: Abortable) => AsyncTask.success(8, abortable));
  } else {
    for (let i = 0; i < 2; i++) {
      try {
        const value = yield YIELD(yield AWAIT((abortable: Abortable) => AsyncTask.success(i, abortable)));
        console.log('value', value);
      } catch {
        console.log('error');
      } finally {
        console.log('finally');
      }
    }
  }

  return '123';
}

const abortable = Abortable.never;

const it = createAsyncTaskIterator(gen());
console.log(await it.next(abortable).toPromise());
console.log(await it.next(1, abortable).toPromise());
console.log(await it.next(2, abortable).toPromise());
```
