import { IAsyncTaskGenerator, IAsyncTaskGeneratorValue } from './async-task-generator.type';
import { IAsyncTaskIterator } from './async-task-iterator.type';
import { isAsyncTaskGeneratorAwaitToken } from './tokens/await/async-task-generator-await-token.type';
import { IAsyncTaskConstraint } from '../async-task/types/async-task-constraint.type';
import { AsyncTask } from '../async-task/async-task.class';
import { Abortable } from '../abortable/abortable.class';
import { IAsyncTaskInput } from '../async-task/types/async-task-input.type';
import { isAsyncTaskGeneratorYieldToken } from './tokens/yield/async-task-generator-value-token.type';

/*
INFO: if an async generator throws, the next promise throws, but not the following promises. The iterator is done if it throws.
 */

export function createAsyncTaskIterator<GValue extends IAsyncTaskConstraint<GValue>, GReturn, GNext>(
  iterator: IAsyncTaskGenerator<GValue, GReturn, GNext>,
): IAsyncTaskIterator<GValue, GReturn, GNext> {
  let queue: AsyncTask<IteratorResult<GValue, GReturn>> | undefined;

  const _iterate = (
    iterate: (abortable: Abortable) => IteratorResult<IAsyncTaskGeneratorValue<GValue>, GReturn>,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>> => {
    return AsyncTask.fromFactory<IteratorResult<IAsyncTaskGeneratorValue<GValue>, GReturn>>(iterate, abortable)
      .successful((
        result: IteratorResult<IAsyncTaskGeneratorValue<GValue>, GReturn>,
        abortable: Abortable,
      ): IAsyncTaskInput<IteratorResult<GValue, GReturn>> => {
        if (result.done) {
          return result;
        } else {
          const token: IAsyncTaskGeneratorValue<GValue> = result.value;

          if (isAsyncTaskGeneratorYieldToken(token)) {
            return {
              done: false,
              value: token.value,
            };
          } else if (isAsyncTaskGeneratorAwaitToken(token)) {
            return AsyncTask.fromFactory(token.factory, abortable)
              .then(
                (
                  value: GValue,
                  abortable: Abortable,
                ): AsyncTask<IteratorResult<GValue, GReturn>> => {
                  return _iterate(
                    () => iterator.next(value),
                    abortable,
                  );
                },
                (
                  error: unknown,
                  abortable: Abortable,
                ): AsyncTask<IteratorResult<GValue, GReturn>> => {
                  return _iterate(
                    () => iterator.throw(error),
                    abortable,
                  );
                },
              );
          } else {
            return AsyncTask.error(
              new Error(`Unknown type: ${token.type}`),
              abortable,
            );
          }
        }
      });
  };

  const _iterateWithQueue = (
    iterate: (abortable: Abortable) => IteratorResult<IAsyncTaskGeneratorValue<GValue>, GReturn>,
    abortable: Abortable,
  ): AsyncTask<IteratorResult<GValue, GReturn>> => {
    return queue = (
      (queue === void 0)
        ? _iterate(iterate, abortable)
        : AsyncTask.switchAbortable(queue, abortable)
          .settled((_, abortable: Abortable): AsyncTask<IteratorResult<GValue, GReturn>> => {
            return _iterate(iterate, abortable);
          })
    );
  };

  return {
    next: (
      ...args: any[]
    ): AsyncTask<IteratorResult<GValue, GReturn>> => {
      if (args.length === 1) {
        return _iterateWithQueue(() => iterator.next(), args[0]);
      } else {
        return _iterateWithQueue(() => iterator.next(args[0]), args[1]);
      }
    },
    return: (
      value: GReturn,
      abortable: Abortable,
    ): AsyncTask<IteratorResult<GValue, GReturn>> => {
      return _iterateWithQueue(() => iterator.return(value), abortable);
    },
    throw: (
      error: any,
      abortable: Abortable,
    ): AsyncTask<IteratorResult<GValue, GReturn>> => {
      return _iterateWithQueue(() => iterator.throw(error), abortable);
    },
  };
}


