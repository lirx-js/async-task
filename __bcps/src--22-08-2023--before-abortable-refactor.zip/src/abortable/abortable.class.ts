import { noop } from '../helpers/noop.private';
import { SingleEventEmitter } from '../helpers/single-event-emitter.class.private';
import { IAbortableDeferReturn } from './types/static-methods/defer/abortable-defer-return.type';
import { IAbortFunction } from './types/init/abort-function.type';
import { IAbortableInit } from './types/init/abortable-init.type';
import { IAbortableUnsubscribe } from './types/methods/on-abort/abortable-unsubscribe.type';
import { unsubscribeSet, IUnsubscribeSet } from '@lirx/unsubscribe';
import { cleanUnsubscribeSet } from '@lirx/unsubscribe/src/unsubscribe-set';

export interface IAbortableDeferInitReturn {
  init: IAbortableInit;
  abort: IAbortFunction;
}


export class Abortable {
  static readonly never: Abortable = new Abortable(noop);

  static deferInit(): IAbortableDeferInitReturn {
    let abort!: IAbortFunction;

    const abortable = new Abortable((
      _abort: IAbortFunction,
    ): void => {
      abort = _abort;
    });

    const init = () => {

    };

    return {
      abortable,
      abort,
    };
  }

  static defer(): IAbortableDeferReturn {
    let abort!: IAbortFunction;

    const abortable = new Abortable((
      _abort: IAbortFunction,
    ): void => {
      abort = _abort;
    });

    return {
      abortable,
      abort,
    };
  }

  static fromAbortSignal(
    signal: AbortSignal,
  ): Abortable {
    return new Abortable((
      abort: IAbortFunction,
    ): void => {
      if (signal.aborted) {
        abort(signal.reason);
      } else {
        signal.addEventListener('abort', (): void => {
          abort(signal.reason);
        }, { once: true });
      }
    });
  }

  static abort(
    reason: any,
  ): Abortable {
    return new Abortable((
      abort: IAbortFunction,
    ): void => {
      abort(reason);
    });
  }

  static timeout(
    ms: number,
  ): Abortable {
    return new Abortable((
      abort: IAbortFunction,
    ): void => {
      setTimeout(() => {
        abort(new Error(`Timeout`));
      }, ms);
    });
  }

  static merge(
    abortables: Abortable[],
    init?: IAbortableInit,
  ): Abortable {
    return new Abortable((
      _abort: IAbortFunction,
    ): void => {
      const toUnsubscribe: IUnsubscribeSet = unsubscribeSet();

      const clean = (): void => {
        cleanUnsubscribeSet(toUnsubscribe);
      };

      const abort = (
        reason: any
      ): void => {
        clean();
        _abort(reason);
      };

      for (let i = 0, l = abortables.length; i < l; i++) {
        const abortable: Abortable = abortables[i];
        if (abortable.aborted) {
          abort(abortable.reason);
          break;
        } else {
          const unsubscribeOfOnAbort: IAbortableUnsubscribe = abortable.onAbort((reason: any): void => {
            unsubscribeOfOnAbort();
            toUnsubscribe.delete(unsubscribeOfOnAbort);
            abort(reason);
          });

          toUnsubscribe.add(unsubscribeOfOnAbort);
        }
      }

      if (init !== void 0) {
        init(abort);
      }
    });
  }

  readonly #abortEventEmitter: SingleEventEmitter<any>;

  constructor(
    init: IAbortableInit,
  ) {
    this.#abortEventEmitter = new SingleEventEmitter<any>();

    init((
      reason: any,
    ): void => {
      if (!this.aborted) {
        this.#abortEventEmitter.emit(reason);
      }
    });
  }

  get aborted(): boolean {
    return this.#abortEventEmitter.done;
  }

  get reason(): any {
    return this.#abortEventEmitter.value;
  }

  onAbort(
    onAbort: IAbortFunction,
  ): IAbortableUnsubscribe {
    return this.#abortEventEmitter.subscribe(onAbort);
  }

  toAbortSignal(): AbortSignal {
    const controller: AbortController = new AbortController();
    if (this.aborted) {
      controller.abort(this.reason);
    } else {
      this.onAbort((): void => {
        controller.abort(this.reason);
      });
    }
    return controller.signal;
  }
}

