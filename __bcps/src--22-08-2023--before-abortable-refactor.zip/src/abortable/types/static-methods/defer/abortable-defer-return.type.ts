import { Abortable } from '../../../abortable.class';
import { IAbortFunction } from '../../init/abort-function.type';
import { IAsyncTaskConstraint } from '../../../../async-task/types/async-task-constraint.type';
import { AsyncTask } from '../../../../async-task/async-task.class';
import { IAsyncTaskSuccessFunction } from '../../../../async-task/types/init/async-task-success-function.type';
import { IAsyncTaskErrorFunction } from '../../../../async-task/types/init/async-task-error-function.type';

/**
 * The return of the Abortable.defer() static method.
 */
export interface IAbortableDeferReturn {
  abortable: Abortable;
  abort: IAbortFunction;
}
