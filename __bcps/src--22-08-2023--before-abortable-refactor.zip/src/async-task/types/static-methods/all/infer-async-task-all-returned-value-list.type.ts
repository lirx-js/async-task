import { IAsyncTaskConstraint } from '../../async-task-constraint.type';
import { InferAsyncTaskValue } from '../../infer-async-task-value.type';
import { IGenericAsyncTaskFactoriesList } from '../../factory/generic-async-task-factories-list.type';

export type InferAsyncTaskAllReturnedValueListRaw<GFactories extends IGenericAsyncTaskFactoriesList> = {
  -readonly [P in keyof GFactories]: InferAsyncTaskValue<ReturnType<GFactories[P]>>;
};

/**
 * Infers the returned values of the static method AsyncTask.all(...)
 */
export type InferAsyncTaskAllReturnedValueList<GFactories extends IGenericAsyncTaskFactoriesList> =
  InferAsyncTaskAllReturnedValueListRaw<GFactories> extends IAsyncTaskConstraint<InferAsyncTaskAllReturnedValueListRaw<GFactories>>
    ? InferAsyncTaskAllReturnedValueListRaw<GFactories>
    : never;
