import { IAsyncTaskAllSettledState } from './async-task-all-settled-state.type';
import { IAsyncTaskConstraint } from '../../async-task-constraint.type';
import { InferAsyncTaskValue } from '../../infer-async-task-value.type';
import { IGenericAsyncTaskFactoriesList } from '../../factory/generic-async-task-factories-list.type';

export type IAsyncTaskAllSettledStateWithConstraint<GValue> =
  GValue extends IAsyncTaskConstraint<GValue>
    ? IAsyncTaskAllSettledState<GValue>
    : never;

export type IAsyncTaskAllSettledValuesListReturnWithoutConstraint<GFactories extends IGenericAsyncTaskFactoriesList> = {
  -readonly [P in keyof GFactories]: IAsyncTaskAllSettledStateWithConstraint<InferAsyncTaskValue<ReturnType<GFactories[P]>>>;
};

/**
 * Infers the returned values of the static method AsyncTask.allSettled(...)
 */
export type IAsyncTaskAllSettledValuesListReturn<GFactories extends IGenericAsyncTaskFactoriesList> =
  IAsyncTaskAllSettledValuesListReturnWithoutConstraint<GFactories> extends IAsyncTaskConstraint<IAsyncTaskAllSettledValuesListReturnWithoutConstraint<GFactories>>
    ? IAsyncTaskAllSettledValuesListReturnWithoutConstraint<GFactories>
    : never;
