export interface IAsyncTaskWhenResolvedUnsubscribe {
  (): void;
}
