/**
 * A function to submit an error.
 */
export interface IAsyncTaskErrorFunction {
  (
    error: any,
  ): void;
}
