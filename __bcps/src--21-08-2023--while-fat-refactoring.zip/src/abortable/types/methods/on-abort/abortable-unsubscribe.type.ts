/**
 * Cancels the subscription of the "onAbort" method.
 */
export interface IAbortableUnsubscribe {
  (): void;
}
