/**
 * A function to abort a task with a reason.
 */
export interface IAbortFunction {
  (
    reason: any,
  ): void;
}
