import { IAsyncTaskSuccessFunction } from './types/init/async-task-success-function.type';
import { IAsyncTaskErrorFunction } from './types/init/async-task-error-function.type';
import { Abortable } from '../abortable/abortable.class';
import { IAsyncTaskResolvedState } from './types/state/async-task-resolved-state.type';
import { AsyncTask } from './async-task.class';
import { IAsyncTaskSuccessState } from './types/state/async-task-success-state.type';
import { noop } from '../noop';
import { IAsyncTaskErrorState } from './types/state/async-task-error-state.type';
import { IAsyncTaskAbortState } from './types/state/async-task-abort-state.type';
import { IAsyncTaskOnResolvedFunction } from './types/methods/resolved/async-task-on-resolved-function.type';
import { IAsyncTaskConstraint } from './types/async-task-constraint.type';

describe('AsyncTask', () => {
  const sleep = (t: number) => {
    return new Promise(_ => setTimeout(_, t));
  };

  /** INIT **/

  /* SUCCESS */
  const successNowTask = new AsyncTask<number>((
    success: IAsyncTaskSuccessFunction<number>,
  ): void => {
    success(1);
  }, Abortable.never);

  const successLaterTask = new AsyncTask<number>((
    success: IAsyncTaskSuccessFunction<number>,
  ): void => {
    setTimeout(() => {
      success(1);
    }, 100);
  }, Abortable.never);

  /* ERROR */
  const errorNowTask = new AsyncTask<number>((
    _: IAsyncTaskSuccessFunction<number>,
    error: IAsyncTaskErrorFunction,
  ): void => {
    error(new Error('Failed'));
  }, Abortable.never);

  errorNowTask.errored(noop);

  const errorLaterTask = new AsyncTask<number>((
    _: IAsyncTaskSuccessFunction<number>,
    error: IAsyncTaskErrorFunction,
  ): void => {
    setTimeout(() => {
      error(new Error('Failed'));
    }, 100);
  }, Abortable.never);

  errorLaterTask.errored(noop);

  /* ABORT */
  const abortNowTask = new AsyncTask<number>(noop, Abortable.abort('aborted'));
  const abortLaterTask = new AsyncTask<number>(noop, Abortable.timeout(100));

  errorNowTask.errored(noop);


  console.log('ok');

  /** TESTS **/

  describe('toPromise', () => {
    describe('success', () => {
      const _test = async (task: AsyncTask<number>) => {
        const value = await successNowTask.toPromise();
        expect(value).toBe(1);
      };

      test('now', async () => {
        await _test(successNowTask);
      });

      test('later', async () => {
        await _test(successLaterTask);
      });
    });

    describe('error', () => {
      const _test = async (task: AsyncTask<number>) => {
        await expect(async () => {
          await task.toPromise();
        })
          .rejects
          .toThrow('Failed');
      };

      test('now', async () => {
        await _test(errorNowTask);
      });

      test('later', async () => {
        await _test(errorLaterTask);
      });
    });

    describe('abort', () => {
      const _test = async (task: AsyncTask<number>) => {
        await expect(async () => {
          await abortNowTask.toPromise();
        })
          .rejects
          .toThrow('Aborted');
      };

      test('now', async () => {
        await _test(abortNowTask);
      });

      test('later', async () => {
        await _test(abortLaterTask);
      });
    });
  });

  describe('settled', () => {

    const testTaskSettled = async <GValue extends IAsyncTaskConstraint<GValue>>(
      task: AsyncTask<GValue>,
      onSettled: IAsyncTaskOnResolvedFunction<GValue, void>,
      abortable: Abortable = task.abortable,
    ): Promise<void> => {
      const spy = jest.fn();
      task.resolved(spy, abortable);
      expect(spy).not.toBeCalled();

      const newTask = task.resolved(onSettled, abortable);

      await newTask.toPromise();
      expect(spy).toBeCalled();
      expect(spy).toHaveBeenCalledTimes(1);
    };

    describe('success', () => {
      const onSettled = (state: IAsyncTaskResolvedState<number>): void => {
        expect(state.state).toBe('success');
        expect((state as IAsyncTaskSuccessState<number>).value).toBe(1);
      };

      test('now', async () => {
        await testTaskSettled(successNowTask, onSettled);
      });

      test('later', async () => {
        await testTaskSettled(successLaterTask, onSettled);
      });
    });

    describe('error', () => {
      const onSettled = (state: IAsyncTaskResolvedState<number>): void => {
        expect(state.state).toBe('error');
        expect((state as IAsyncTaskErrorState).error).toBeDefined();
      };

      test('now', async () => {
        await testTaskSettled(errorNowTask, onSettled);
      });

      test('later', async () => {
        await testTaskSettled(errorLaterTask, onSettled);
      });
    });

    describe('abort', () => {
      const onSettled = (state: IAsyncTaskResolvedState<number>): void => {
        expect(state.state).toBe('abort');
        expect((state as IAsyncTaskAbortState).reason).toBeDefined();
      };

      test('now', async () => {
        await testTaskSettled(abortNowTask, onSettled, Abortable.never);
      });

      test('later', async () => {
        await testTaskSettled(abortLaterTask, onSettled, Abortable.never);
      });

      test('new AsyncTask aborted', async () => {
        const spy = jest.fn();
        const newTask = abortNowTask.resolved(spy, Abortable.abort('Aborted'));
        expect(spy).not.toBeCalled();

        await expect(async () => {
          await newTask.toPromise();
        })
          .rejects
          .toThrow('Aborted');

        expect(spy).not.toBeCalled();
      });
    });

    describe('chain', () => {
      describe('success', () => {
        const onSettled = (state: IAsyncTaskResolvedState<number>): void => {
          expect(state.state).toBe('success');
          expect((state as IAsyncTaskSuccessState<number>).value).toBe(2);
        };

        test('value', async () => {
          await testTaskSettled(
            successNowTask.resolved((): number => {
              return 2;
            }, successNowTask.abortable),
            onSettled,
          );
        });

        test('Promise', async () => {
          await testTaskSettled(
            successNowTask.resolved((): Promise<number> => {
              return Promise.resolve(2);
            }, successNowTask.abortable),
            onSettled,
          );
        });

        test('AsyncTask', async () => {
          await testTaskSettled(
            successNowTask.resolved((_, abortable: Abortable): AsyncTask<number> => {
              return AsyncTask.success(2, abortable);
            }, successNowTask.abortable),
            onSettled,
          );
        });
      });

      describe('error', () => {
        const onSettled = (state: IAsyncTaskResolvedState<any>): void => {
          expect(state.state).toBe('error');
          expect((state as IAsyncTaskErrorState).error).toBeDefined();
        };

        const multiTest = async (
          _onSettled: IAsyncTaskOnResolvedFunction<any, any>,
        ) => {
          await testTaskSettled(
            successNowTask.resolved<any>(_onSettled, successNowTask.abortable),
            onSettled,
          );

          await testTaskSettled(
            errorNowTask.resolved<any>(_onSettled, errorNowTask.abortable),
            onSettled,
          );

          await testTaskSettled(
            abortNowTask.resolved<any>(_onSettled, Abortable.never),
            onSettled,
          );
        };

        test('value', async () => {
          await multiTest((): never => {
            throw 'Error';
          });
        });

        test('Promise', async () => {
          await multiTest((): Promise<never> => {
            return Promise.reject('Error');
          });
        });

        test('AsyncTask', async () => {
          await multiTest((_, abortable: Abortable): AsyncTask<never> => {
            return AsyncTask.error('Error', abortable);
          });
        });
      });
    });
  });

  describe('then', () => {
    describe('success', () => {
      test('has been called', async () => {
        const spy1 = jest.fn();
        const spy2 = jest.fn();
        const newTask = successLaterTask.then(spy1, spy2);
        expect(spy1).not.toBeCalled();
        expect(spy2).not.toBeCalled();

        await newTask.toPromise();
        expect(spy1).toBeCalled();
        expect(spy1).toHaveBeenCalledTimes(1);
        expect(spy2).not.toBeCalled();

      });

      test('received correct value', async () => {
        await successLaterTask
          .then((value: number) => {
            expect(value).toBe(1);
          }, noop)
          .toPromise();
      });

      test('chain', async () => {
        await successLaterTask
          .then((value: number): number => {
            return value * 2;
          }, e => {
            throw e;
          })
          .then((value: number): void => {
            expect(value).toBe(2);
          }, e => {
            throw e;
          })
          .toPromise();
      });
    });

    describe('error', () => {
      test('has been called', async () => {
        const spy1 = jest.fn();
        const spy2 = jest.fn();
        const newTask = errorLaterTask.then(spy1, spy2);
        expect(spy1).not.toBeCalled();
        expect(spy2).not.toBeCalled();

        await newTask.toPromise();
        expect(spy1).not.toBeCalled();
        expect(spy2).toBeCalled();
        expect(spy2).toHaveBeenCalledTimes(1);
      });

      test('received correct value', async () => {
        await errorLaterTask
          .then(noop, (error: any) => {
            expect(error.message).toBe('Failed');
          })
          .toPromise();
      });

      test('chain', async () => {
        await errorLaterTask
          .then<number>(noop as any, () => {
            return 2;
          })
          .then((value: number): void => {
            expect(value).toBe(2);
            throw new Error('Error');
          }, e => {
            throw e;
          })
          .then(noop, (error: any) => {
            expect(error.message).toBe('Error');
          })
          .toPromise();
      });
    });

    describe('abort', () => {
      test('has been called', async () => {
        const spy1 = jest.fn();
        const spy2 = jest.fn();
        const newTask = abortLaterTask.then(spy1, spy2);
        expect(spy1).not.toBeCalled();
        expect(spy2).not.toBeCalled();

        await expect(async () => {
          await newTask.toPromise();
        })
          .rejects
          .toThrow('Aborted');
        expect(spy1).not.toBeCalled();
        expect(spy2).not.toBeCalled();
      });
    });
  });

  describe('successful', () => {
    describe('success', () => {
      test('has been called', async () => {
        const spy = jest.fn();
        const newTask = successLaterTask.successful(spy);
        expect(spy).not.toBeCalled();

        await newTask.toPromise();
        expect(spy).toBeCalled();
        expect(spy).toHaveBeenCalledTimes(1);
      });

      test('received correct value', async () => {
        await successLaterTask
          .successful((value: number) => {
            expect(value).toBe(1);
          })
          .toPromise();
      });

      test('chain', async () => {
        await successLaterTask
          .successful((value: number): number => {
            return value * 2;
          })
          .successful((value: number): void => {
            expect(value).toBe(2);
          })
          .toPromise();
      });
    });

    describe('error', () => {
      test('has been called', async () => {
        const spy = jest.fn();
        const newTask = errorLaterTask.successful(spy);
        expect(spy).not.toBeCalled();

        await expect(async () => {
          await newTask.toPromise();
        })
          .rejects
          .toThrow('Failed');
        expect(spy).not.toBeCalled();
      });

      test('chain', async () => {
        await expect(async () => {
          await errorLaterTask
            .successful(() => {
              return 2;
            })
            .toPromise();
        })
          .rejects
          .toThrow('Failed');
      });
    });

    describe('abort', () => {
      test('has been called', async () => {
        const spy = jest.fn();
        const newTask = abortLaterTask.successful(spy);
        expect(spy).not.toBeCalled();

        await expect(async () => {
          await newTask.toPromise();
        })
          .rejects
          .toThrow('Aborted');
        expect(spy).not.toBeCalled();
      });
    });
  });

  describe('errored', () => {
    describe('success', () => {
      test('has been called', async () => {
        const spy = jest.fn();
        const newTask = successLaterTask.errored(spy);
        expect(spy).not.toBeCalled();

        await newTask.toPromise();
        expect(spy).not.toBeCalled();
      });


      test('chain', async () => {
        await successLaterTask
          .errored(noop as any)
          .successful((value: number): void => {
            expect(value).toBe(1);
          })
          .toPromise();
      });
    });

    describe('error', () => {
      test('has been called', async () => {
        const spy = jest.fn();
        const newTask = errorLaterTask.errored(spy);
        expect(spy).not.toBeCalled();

        await newTask.toPromise();
        expect(spy).toBeCalled();
      });

      test('received correct value', async () => {
        await errorLaterTask
          .errored((error: any) => {
            expect(error.message).toBe('Failed');
          })
          .toPromise();
      });

      test('chain', async () => {
        const value = await errorLaterTask
          .errored(() => {
            return 2;
          })
          .toPromise();

        expect(value).toBe(2);
      });
    });

    describe('abort', () => {
      test('has been called', async () => {
        const spy = jest.fn();
        const newTask = abortLaterTask.errored(spy);
        expect(spy).not.toBeCalled();

        await expect(async () => {
          await newTask.toPromise();
        })
          .rejects
          .toThrow('Aborted');
        expect(spy).not.toBeCalled();
      });
    });
  });

});
