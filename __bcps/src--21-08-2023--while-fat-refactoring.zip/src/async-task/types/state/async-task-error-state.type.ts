export interface IAsyncTaskErrorState {
  readonly state: 'error';
  readonly error: any;
}
