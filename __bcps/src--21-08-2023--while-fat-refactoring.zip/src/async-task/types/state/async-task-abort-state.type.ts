export interface IAsyncTaskAbortState {
  readonly state: 'abort';
  readonly reason: any;
}
