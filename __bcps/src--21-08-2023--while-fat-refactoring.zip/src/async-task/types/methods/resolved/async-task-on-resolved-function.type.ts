import { Abortable } from '../../../../abortable/abortable.class';
import { IAsyncTaskConstraint } from '../../async-task-constraint.type';
import { IAsyncTaskInput } from '../../async-task-input.type';
import { IAsyncTaskResolvedState } from '../../state/async-task-resolved-state.type';

/**
 * A function called when an AsyncTask reaches a "resolved" state (success, error, or abort) .
 * It receives the "state", and an Abortable used if the return is another AsyncTask.
 */
export interface IAsyncTaskOnResolvedFunction<GValue extends IAsyncTaskConstraint<GValue>, GNewValue extends IAsyncTaskConstraint<GNewValue>> {
  (
    state: IAsyncTaskResolvedState<GValue>,
    abortable: Abortable,
  ): IAsyncTaskInput<GNewValue>;
}
