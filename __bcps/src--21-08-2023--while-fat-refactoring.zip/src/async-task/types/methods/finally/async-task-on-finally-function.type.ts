import { Abortable } from '../../../../abortable/abortable.class';
import { IAsyncTaskConstraint } from '../../async-task-constraint.type';
import { IAsyncTaskInput } from '../../async-task-input.type';
import { IAsyncTaskResolvedState } from '../../state/async-task-resolved-state.type';

/**
 * A function called when an AsyncTask enters in an "final" state (success, error, or abort) .
 * It receives the "state", and an Abortable used if the return is another AsyncTask.
 */
export interface IAsyncTaskOnFinallyFunction<GValue extends IAsyncTaskConstraint<GValue>> {
  (
    state: IAsyncTaskResolvedState<GValue>,
    abortable: Abortable,
  ): IAsyncTaskInput<void>;
}
